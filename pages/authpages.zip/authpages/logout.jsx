import React from "react";

const logout = () => {
  return <div>logout</div>;
};

export default logout;
